export class RegistrationModel {
    constructor(public fname:string, public lname:string, public email:string,public mobile:number,public notifications:boolean){}
}