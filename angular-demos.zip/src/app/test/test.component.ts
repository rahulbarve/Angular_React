import { Component, OnInit, Input, EventEmitter, Output} from '@angular/core';
import {EmployeeService} from 'src/app/employee.service';

@Component({
  selector: 'app-test',
  template: `
    <!--
    <h2 class="text-success">Welcome to Angular</h2>
     <h2 [class]="successClass" class="text-special">Welcome to Angular</h2>
     <h2 [class.text-danger]="hasError">Welcome to Angular</h2>
     <h2 [ngClass]="myClasses">Welcome to Angular</h2>
     <h2 [style.color]="foreColor">Style Binding</h2>
     <h2 [style.color]="hasError ? 'red' : 'green'">Conditional Style Binding</h2>
     <h2 [ngStyle] = "myStyles">Multiple Style Binding</h2>
     <button (click)="onClick()">Change the Name below</button>
     
     
     Enter your name: <input type="text" #myName/>
     <input type="button" value="Say Greeting" (click)="onClick(myName)"/>
    
     Enter your name: <input type="text" [(ngModel)]="name"/>
     <h2>{{name}}</h2> 
     
     <div *ngIf="percentage > 60; then firstBlock; else secondBlock">
     </div>
     <ng-template #firstBlock>
      <h2>
        First Class
      </h2>
     </ng-template>
     <ng-template #secondBlock>
      <div *ngIf="percentage > 40 then thirdBlock; else lastBlock">
      </div>  
     </ng-template>
     <ng-template #thirdBlock>
      <h2>
        Second Class
      </h2>
     </ng-template>
     <ng-template #lastBlock>
      <h2>
        Fail
      </h2>
     </ng-template>
     <div [ngSwitch] = "color">
      <div *ngSwitchCase = "'red'">Picked Red</div>
      <div *ngSwitchCase = "'green'">Picked Green</div>
      <div *ngSwitchCase = "'blue'">Picked Blue</div>
      <div *ngSwitchDefault>Pick Again</div>
     </div>
     <div *ngFor = "let clr of colors;index as i; first as f; last as l; even as e; odd as o">
      <h2>{{i}}  {{clr}} {{f}} {{l}} {{e}} {{o}}</h2>
     </div>
    
     <div *ngFor = "let p of planets">
      <h2>{{p.name}} {{p.moons}}</h2>
     </div>
      
      <h2>Parent says: {{messageFromParent}}</h2>
      <input type="button" (click) = "fireEvent()" value = "Send To Parent"/>
     
     <h2>{{message}}</h2>
     <h2>{{message | lowercase}}</h2>
     <h2>{{message | uppercase}}</h2>
     <h2>{{message | titlecase}}</h2>
     <h2>{{message | slice}}</h2>
     <h2>{{message | slice:3}}</h2> 
     <h2>{{message | slice:3:5}}</h2>
     <h2>{{myStyles | json}}</h2>
     
     <h2>{{45.765 | number:'1.1-3'}}</h2>
     <h2>{{45.765 | number:'3.1-2'}}</h2>
     <h2>{{45.765 | number:'5.2-6'}}</h2>
     

     <h2>{{0.735 | percent}}</h2>
     <h2>{{1243 | currency}}</h2>
     <h2>{{1243 | currency : 'GBP'}}</h2>
     <h2>{{1243 | currency : 'EUR'}}</h2>
     <h2>{{1243 | currency : 'INR'}}</h2>
     <h2>{{1243 | currency : 'JPY'}}</h2>
     
     <h2>{{sysDate}}</h2>
     <h2>{{customDate}}</h2>
     <h2>{{sysDate | date}}</h2>
     <h2>{{sysDate | date : 'short'}}</h2>
     <h2>{{customDate | date : 'shortDate'}}</h2>
     <h2>{{customDate | date : 'shortTime'}}</h2>
     
     
      
      <h2>{{5 | mySquare}}</h2>
     
     -->
     <div *ngFor = "let emp of employeeData">
      <h2>{{emp.empNo}} {{emp.name}} {{emp.sal}}</h2>
     </div>
  `,
  styles:[`
    .text-success {
      color : green;
    }
    .text-danger {
      color : red;
    }
    .text-special {
      font-style : italic;
    }
  `]
})
export class TestComponent implements OnInit {
  employeeData = null;
  userData = {};
  customDate = new Date(2020,7,15,0,0,0);
  sysDate = new Date();
  @Input('parentData') messageFromParent;
  @Output() childEvent = new EventEmitter();
  colors = ["red","green","blue","yellow","orange"];
  planets = [
    {name:"Earth",moons: 1},
    {name:"Mars",moons: 2},
    {name:"Jupiter",moons: 16},
    ];
  percentage = 65;
  color = "yellow"; 
  name = "";
  message = "Welcome to all of you";
  successClass = "text-success";
  hasError = false;
  isSpecial = true;
  foreColor = "pink";

  

  myClasses = {
    "text-success" : !this.hasError,
    "text-danger" : this.hasError,
    "text-special" : this.isSpecial
  };

  myStyles = {
    "color" : "red",
    "background-color" : "black",
    "font-style" : "italic"
  };
  constructor(private _empService : EmployeeService) {

   }
   
  ngOnInit() {
    /*this._empService.getUsers()
    .subscribe(data => this.userData = data);*/

  //  this.employeeData = this._empService.getEmployees();
    this._empService.getEmployees()
    .subscribe(data => this.employeeData = data);
    
  }

  getGreetingMessage(){
    return "Hello " + this.name;
  }

  onClick(myNm){
    //console.log('Button is clicked');
    this.message = "Welcome to all of you";
    this.name = myNm.value;
  }

  fireEvent(){
    this.childEvent.emit("Thank you parent");
  }

}



