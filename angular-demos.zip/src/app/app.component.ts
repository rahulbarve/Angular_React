import { Component } from '@angular/core';
import { RegistrationModel } from './RegModel';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html' ,
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Angular';  
  message = "Happy New Year";
  messageFromChild = "";
  getTitle(){
    return this.title;
  }
  regModel = new RegistrationModel("Neel","Joshi","neelj@gmail.com",5948594858,true);
  
}
