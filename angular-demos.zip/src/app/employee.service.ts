import { Injectable } from '@angular/core';
import { HttpClient} from '@angular/common/http'; 
import { IUser } from './IUser';
import { IEmployee } from './IEmployee';
import { Observable } from 'rxjs';
@Injectable()
export class EmployeeService {
  //serviceUrl = "https://jsonplaceholder.typicode.com/todos/1";
  serviceUrl = "/assets/employees.json";
  constructor(private http : HttpClient) { }
  getUsers():Observable<IUser>{
        
    return this.http.get<IUser>(this.serviceUrl);
  }
  getEmployees():Observable<IEmployee>{
    
    return this.http.get<IEmployee>(this.serviceUrl);
    
  }
}
