export interface IEmployee {
    empNo : number;
    name : string;
    sal : number;
}