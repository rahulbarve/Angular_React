import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-emp-list',
  template: `
  ` ,
  styleUrls: ['./emp-list.component.css']
})
export class EmpListComponent implements OnInit {
  employeeData = [
    {"empNo":1001,"name":"James","salary":40000},
    {"empNo":1001,"name":"James","salary":40000},
    {"empNo":1001,"name":"James","salary":40000},
    {"empNo":1001,"name":"James","salary":40000}
  ];
  constructor() { }

  ngOnInit() {
  }

}
