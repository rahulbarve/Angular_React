import React from 'react';
import { Component } from 'react';
class ChildComponent extends Component {
    constructor(props){
        super(props);
        this.state = {
            message : 'Welcome'
        }
        console.log('Child constructor')
    }
    static getDerivedStateFromProps(props, state){
        console.log('Child getDerivedStateFromProps')
        return null;
    }
    componentDidMount(){
        console.log('Child componentDidMount')
    }
    render(){
        console.log('Child render()')
        return(
            <div>
                <h2>Child Component</h2>                
            </div>
        )
    }
}
export default ChildComponent