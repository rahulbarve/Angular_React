import React from 'react';

const Greeting = (props) => {
    console.log(props);
    return (
        <div>
            <h1>{props.message} {props.name}</h1>   
            {props.children}
        </div>
    ) 
}

export default Greeting;
