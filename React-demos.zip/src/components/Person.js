import React from 'react';
function Person({personData}){
    return (
        <div><h2>Profession of {personData.name} is {personData.profession}</h2></div>
    )
}

export default Person;