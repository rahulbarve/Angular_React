import React from 'react';
function NameList(){
    const names = ["Akshay", "Deepika", "Ranveer"];
    const nameList = names.map(name => <h2>{name}</h2>)
    const persons = 
        [{name:'p1',age:20},{name:'p2',age:25}]
    const personList = 
    persons.map(person => <h2>{person.name}</h2>)    
    return (
        <div>
                {/*{names.map(name => <h2>{name}</h2>)}
                {nameList}  */
                personList
                }         

        </div>
    )
}

export default NameList