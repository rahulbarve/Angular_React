import React from 'react';
import { Component } from 'react';
class FormComponent extends Component {
    constructor(){
        super();
        this.state = {
            fname : '',
            lname : ''
        }
    }

    handleFirstnameChange = (event) => {
        this.setState({
            fname : event.target.value
        })

    }

    handleLastnameChange = (event) => {
        this.setState({
            lname : event.target.value
        })
    }

    handleSubmit = (event) => {
        alert(`${this.state.fname} ${this.state.lname}`)
        event.preventDefault();
    }
    render(){
        return(
            <form onSubmit={this.handleSubmit}>
                <div>
                    <label>First Name:  </label>
                    <input type='text' value={this.state.fname} onChange={this.handleFirstnameChange}/>
                </div>

                <div>
                    <label>Last Name:  </label>
                    <input type='text' value={this.state.lname} onChange={this.handleLastnameChange}/>
                </div>

                <button type="submit">Submit</button>
            </form>
        )
    }
}

export default FormComponent