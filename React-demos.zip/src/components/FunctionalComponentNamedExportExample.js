import React from 'react'
export function SayHello(){
    return  <h1>This is another functional component </h1>
}




