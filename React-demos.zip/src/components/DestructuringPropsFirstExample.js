import React from 'react';

const Greeting_DS1 = ({message, name}) => {
    
    return (
        <div>
            <h1>{message} {name}</h1>            
        </div>
    ) 
}

export default Greeting_DS1;
