import React from 'react';

const Greeting_DS2 = (props) => {
    const {message, name} = props;
    return (
        <div>
            <h1>{message} {name}</h1>            
        </div>
    ) 
}

export default Greeting_DS2;
