import React from 'react';
import PersonChild from './Person';
function PersonList(){
    const persons = [
        {name : "Akshay Kumar", profession : "Actor"},
        {name : "Arijit Singh", profession : "Singer"},
        {name : "MS Dhoni", profession : "Cricketer"}
    ];
//const personList = persons.map(person => <h2>Profession of {person.name} is {person.profession}</h2>)
const personList = persons.map(myperson => <PersonChild personData = {myperson}></PersonChild>)
    return (
        <div>
            {/* <h2>{names[0]}</h2>
            <h2>{names[1]}</h2>
            <h2>{names[2]}</h2> */
                //names.map(name => <h2>{name}</h2>)
                personList
            }

        </div>
    )
}

export default PersonList