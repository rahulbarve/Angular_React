import React from 'react';
function Inline(){
    let heading = {
        color : 'red',
        backgroundColor: 'yellow'
    }
    return(
        <div>
            <h1 style={heading}>Inline Style</h1>
            
        </div>
    )
}

export default Inline;