import React, { Component } from 'react';
import axios from 'axios';
class HttpComponent extends Component {
    constructor(props){
        super(props);
        this.state = {
            users : []
        }
    }
    componentDidMount(){
        axios.get('http://jsonplaceholder.typicode.com/users')
        .then(response => {
            this.setState({users : response.data})
        })
        .catch(error => {
            console.log(error);
        })
    }
    render(){
        const {users} = this.state;
        return(
            <div>
                {
                    users.map(user => <div key={user.id}>{user.name} =>    {user.email}</div>)
                }
            </div>
        )
    }
}

export default HttpComponent