import React from 'react';
import { Component } from 'react';
import Child from './ChildLifeCycleExample';
class ParentComponent extends Component {
    constructor(props){
        super(props);
        this.state = {
            message : 'Welcome'
        }
        console.log('Parent constructor')
    }
    static getDerivedStateFromProps(props, state){
        console.log('Parent getDerivedStateFromProps')
        return null;
    }
    componentDidMount(){
        console.log('Parent componentDidMount')
    }
    render(){
        console.log('Parent render()')
        return(
            <div>
                <h2>Parent Component</h2>     
                <Child/>           
            </div>
        )
    }
    componentDidMount(){
        console.log('Parent componentDidMount')
    }
}
export default ParentComponent