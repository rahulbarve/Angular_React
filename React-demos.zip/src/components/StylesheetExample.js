import React from 'react';
import './Stylesheet.css';
function StyleSheet(props){
    let className = props.primary ? 'primary' : ''
    let className2 = props.bigFont ? 'bigFont' : ''
    return (
        <div>
            {/* <h1 className={className}>Welcome to StyleSheet</h1> */}
            <h1 className={`${className} ${className2}`}>Welcome to StyleSheet</h1>
            
        </div>
    )
}

export default StyleSheet