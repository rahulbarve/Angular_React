import React, {Component} from 'react';

class Welcome extends Component {
    render(){
        return(
            <div>
                <h1>This is a class component</h1>
                <h1>This is a class component Ex</h1>
           </div>     
        ) 
    }
}

export default Welcome;