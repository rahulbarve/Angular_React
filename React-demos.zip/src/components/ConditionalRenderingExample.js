import React, {Component} from 'react';
class UserGreeting extends Component {
    constructor(props){
        super(props);
        this.state = {
            isLoggedIn : true
        }
    }
    render(){
        //Short Circuit Operator Approach
        return this.state.isLoggedIn && <div>Welcome Jack</div>
        //Conditional Ternary Operator Approach
        /* return (
            this.state.isLoggedIn ? <div>Welcome Jack</div> : <di>Welcome Guest</di>
        ) */
        //Element Variable Approach
        /* let message;
        if(this.state.isLoggedIn){
            message =  <div><h3>Welcome Jack</h3></div>            
        }
        else {
            message =  <div><h3>Welcome Guest</h3></div>           
        }
        return <div>{message}</div> */

        //if...else approach
        /* if(this.state.isLoggedIn){
            return <div><h3>Welcome Jack</h3></div>            
        }
        else {
            return <div><h3>Welcome Guest</h3></div>           
        } */
        /* return(
            <div>
                <h3>Welcome Jack</h3>
                <h3>Welcome Guest</h3>
            </div>
        ) */
    }
}

export default UserGreeting