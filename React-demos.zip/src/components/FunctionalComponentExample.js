import React from 'react'
/* function sayHello(){
    return <h1>This is a functional component</h1>
} */

export const SayHello = () => <h1>This is a functional component</h1>
//export default sayHello


