import React, {Component} from 'react';


class Welcoming extends Component {
    render(){
    return <h1>Welcome {this.props.fname} {this.props.lname}</h1>
    }
}

export default Welcoming;
