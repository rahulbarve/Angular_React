import React from 'react';
import logo from './logo.svg';
import './App.css';
import {SayHello} from './components/FunctionalComponentExample'
import Welcome from './components/ClassComponentExample'

function App() {
  return (
    <div className="App">
      <SayHello/>
      <Welcome/>
    </div>
  );
}

export default App;
