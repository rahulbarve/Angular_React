class Animal {
   protected animalId: number;
    constructor(){
        this.animalId = 101;
    }    
}

class Dog extends Animal {
    dogName:string;
    constructor(){
        super();
        this.dogName = "Alex";
    }
    getInfo(){
        return this.animalId + ", " + this.dogName;
    }
}
let dog = new Dog();
console.log(dog.getInfo());