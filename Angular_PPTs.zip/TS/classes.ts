class GreetingService {
    personName : string;
    greetingMessage : string;
    constructor(personName:string, greetingMessage:string){
        this.personName = personName;
        this.greetingMessage = greetingMessage;        
    }
    sayGreeting(){
        let finalMessage : string = 
        this.greetingMessage.toUpperCase() + " " + this.personName.toUpperCase();
        return finalMessage;
    }
}
let gs1:GreetingService = new GreetingService("Neel","Welcome");
let msg:string = gs1.sayGreeting();
console.log(msg);
