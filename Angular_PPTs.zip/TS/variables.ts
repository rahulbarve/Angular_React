let ne;
ne = 100;
console.log(ne);
ne = "Welcome";
console.log(ne);
