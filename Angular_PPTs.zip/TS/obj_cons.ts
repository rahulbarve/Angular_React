let pers = {fname:"Rahul"};
let fn = pers.fname;