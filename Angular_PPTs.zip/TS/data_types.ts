let num:number = 100; let nm:string = 'James';
let isSuccessful:boolean = true;let scores:number[] = [45,67,34,76,54];
let names:Array<string> = ["Virat","Rohit","Shikhar","Shreyas"];
let empRow1:[number, string] = [101, "James"];
let empRow2:[string, number] = ["Jasmine",102];
enum AccountStatus {OPEN, ACTIVE, CLOSED};
let accStatus : AccountStatus = AccountStatus.ACTIVE;
let x;
for( x in scores){
    console.log(scores[x]);
}
if(isSuccessful)
    console.log("Success");
let n;
for(n in names){
    console.log(names[n].toUpperCase());
}
console.log("Emp No: " + empRow1[0] + " Name: " + empRow1[1]);
console.log("Emp No: " + empRow2[1] + " Name: " + empRow2[0]);
console.log(accStatus);
