class Player {
    name:string;
    age : number;
    constructor(name:string, age:number){
        this.name = name;
        this.age = age;
    }
    getInfo(){
        return this.name + " " + this.age;
    }
}
class CricketPlayer extends Player {
    runs : number;
    constructor(name:string, age:number, runs:number){
        super(name,age);
        this.runs = runs;
    }
    getInfo(){
        return super.getInfo() + " " + this.runs;
    }
}
let cp:CricketPlayer = new CricketPlayer("Virat", 31, 13456);
let info:string = cp.getInfo();
console.log(info);