"use strict";
var GreetingService = /** @class */ (function () {
    function GreetingService(personName, greetingMessage) {
        this.personName = personName;
        this.greetingMessage = greetingMessage;
    }
    GreetingService.prototype.sayGreeting = function () {
        var finalMessage = this.greetingMessage.toUpperCase() + " " + this.personName.toUpperCase();
        return finalMessage;
    };
    return GreetingService;
}());
var gs1 = new GreetingService("Neel", "Welcome");
var msg = gs1.sayGreeting();
console.log(msg);
