"use strict";
var pers = { fname: "James", age: 65 };
var fn2 = pers.fname;
var ag2 = pers.age;
console.log(fn2 + " " + ag2);
//const {fname:fn1,age:ag1} = pers;
//console.log(fn1 + " " + ag1);
