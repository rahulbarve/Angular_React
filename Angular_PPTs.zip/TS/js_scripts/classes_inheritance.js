"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Player = /** @class */ (function () {
    function Player(name, age) {
        this.name = name;
        this.age = age;
    }
    Player.prototype.getInfo = function () {
        return this.name + " " + this.age;
    };
    return Player;
}());
var CricketPlayer = /** @class */ (function (_super) {
    __extends(CricketPlayer, _super);
    function CricketPlayer(name, age, runs) {
        var _this = _super.call(this, name, age) || this;
        _this.runs = runs;
        return _this;
    }
    CricketPlayer.prototype.getInfo = function () {
        return _super.prototype.getInfo.call(this) + " " + this.runs;
    };
    return CricketPlayer;
}(Player));
var cp = new CricketPlayer("Virat", 31, 13456);
var info = cp.getInfo();
console.log(info);
