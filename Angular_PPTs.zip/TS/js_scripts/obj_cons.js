"use strict";
var pers = { fname: "Rahul" };
var fn = pers.fname;
