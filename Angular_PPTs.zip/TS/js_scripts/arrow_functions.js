"use strict";
var getNum = function () { return 100; };
var num1 = getNum();
console.log(num1);
var getFixedNum = function (numParam2) { return numParam2; };
var num2 = getFixedNum(100);
console.log(num2);
var getSum = function (n1, n2) { return n1 + n2; };
var sumValue = getSum(50, 25);
console.log(sumValue);
var getFact = function (n1) {
    var fact = 1;
    var x;
    for (x = 1; x <= n1; x++) {
        fact *= x;
    }
    return fact;
};
var fact5 = getFact(5);
console.log(fact5);
var getSumOfNumbers = function () {
    var params = [];
    for (var _i = 0; _i < arguments.length; _i++) {
        params[_i] = arguments[_i];
    }
    var total = 0;
    var x;
    for (x in params) {
        total += params[x];
    }
    return total;
};
var total1 = getSumOfNumbers(1, 2, 3);
console.log(total1);
var total2 = getSumOfNumbers(4, 5);
console.log(total2);
