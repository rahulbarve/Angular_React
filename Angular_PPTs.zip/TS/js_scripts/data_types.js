"use strict";
var num = 100;
var nm = 'James';
var isSuccessful = true;
var scores = [45, 67, 34, 76, 54];
var names = ["Virat", "Rohit", "Shikhar", "Shreyas"];
var empRow1 = [101, "James"];
var empRow2 = ["Jasmine", 102];
var AccountStatus;
(function (AccountStatus) {
    AccountStatus[AccountStatus["OPEN"] = 0] = "OPEN";
    AccountStatus[AccountStatus["ACTIVE"] = 1] = "ACTIVE";
    AccountStatus[AccountStatus["CLOSED"] = 2] = "CLOSED";
})(AccountStatus || (AccountStatus = {}));
;
var accStatus = AccountStatus.ACTIVE;
var x;
for (x in scores) {
    console.log(scores[x]);
}
if (isSuccessful)
    console.log("Success");
var n;
for (n in names) {
    console.log(names[n].toUpperCase());
}
console.log("Emp No: " + empRow1[0] + " Name: " + empRow1[1]);
console.log("Emp No: " + empRow2[1] + " Name: " + empRow2[0]);
console.log(accStatus);
