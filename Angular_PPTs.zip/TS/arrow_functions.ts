let getNum = () => 100;
let num1 = getNum();
console.log(num1);


let getFixedNum = (numParam2:any) => numParam2;
let num2 = getFixedNum(100);
console.log(num2);

let getSum = (n1:number, n2:number) => n1 + n2;
let sumValue = getSum(50,25);
console.log(sumValue);

let getFact = (n1:number) => {
    let fact = 1;
    let x;
    for(x=1;x<=n1;x++){
        fact *= x;
    }
    return fact;
};

let fact5 = getFact(5);
console.log(fact5);

let getSumOfNumbers = (...params:number[]) => {
    let total = 0;
    let x;
    for(x in params){
        total += params[x];
    }
    return total;
};

let total1 = getSumOfNumbers(1,2,3);
console.log(total1);

let total2 = getSumOfNumbers(4,5);
console.log(total2);



